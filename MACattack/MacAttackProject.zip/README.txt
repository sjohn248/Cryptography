Program compiled using VScode and g++. Ran using ./a.exe

originalMessage, originalMAC, and newMessage can be changed in main on lines 230, 231, 232 for desired output