Compile program with                    "g++ AES.cpp"
Run program with                        "./a.exe"
Pipe output to file                     "./a.exe >> output.txt"
Compare with grading output with diff   "diff output.txt correct.txt"

I only looked at resources listed above.
Only lines that show up should be the equivalent inverse cipher output. I compiled my code on both VScode and our tesla lab machine.

